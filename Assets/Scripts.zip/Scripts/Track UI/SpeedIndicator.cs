﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SpeedIndicator : MonoBehaviour
{
    Rigidbody rb;
    PlayerMovement pm;
    public Text display;
    public RectTransform rt;

    private void Start()
    {
        rb = GameObject.FindGameObjectWithTag("Car").GetComponent<Rigidbody>();
        pm = GameObject.FindGameObjectWithTag("Car").GetComponent<PlayerMovement>();
    }

    void Update()
    {
        try
        {
            display.text = Mathf.Round(rb.velocity.magnitude * 3.6f).ToString();
        }
        catch (System.NullReferenceException)
        {
            return;
        }
        rt.rotation = Quaternion.Euler(0, 0, (rb.velocity.magnitude / pm.maxSpeed * -90));
    }
}
