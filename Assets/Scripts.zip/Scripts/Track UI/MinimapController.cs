﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MinimapController : MonoBehaviour
{
    Transform car;
    public RectTransform dotRc;
    public Image image;
    public Sprite minimapPng;
    public Vector2 offset;
    //public Vector2 scale = new Vector2(1, 1);
    Renderer carColour;
    RectTransform mapRc;
    // Start is called before the first frame update
    void Start()
    {
        carColour = GameObject.FindGameObjectWithTag("Car Body").GetComponent<Renderer>();
        car = GameObject.FindGameObjectWithTag("Car").transform;
        dotRc.gameObject.GetComponent<Image>().color = carColour.material.color;
        image.sprite = minimapPng;
        mapRc = image.gameObject.GetComponent<RectTransform>();
    }

    void GetCoordinates()
    {
        mapRc.anchoredPosition = new Vector2(Screen.width / 2 - 150 + offset.x, -1 * Screen.height / 2 + 150 + offset.y);
        Vector2 pos;
        pos.x = (Screen.width / 2 - 250 + ((car.position.x) / 5 + 124.6f) + offset.x);
        pos.y = ((car.position.z) / 5 + 152f) - Screen.height / 2 + offset.y;
        dotRc.anchoredPosition = pos;
    }

    //void Scale()
    //{
    //   Vector3 _s = new Vector3(scale.x, scale.y, 1);
    //    mapRc.localScale = _s;
    //    dotRc.localScale = _s;
    //}

    void Update()
    {
        GetCoordinates();
        //Scale();
    }
}
