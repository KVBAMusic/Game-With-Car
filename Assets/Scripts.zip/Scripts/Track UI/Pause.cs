﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Pause : MonoBehaviour
{
    public GameObject pauseScreen, speedGauge, miniMap;
    public AudioController ac;
    public Slider musicVolume, sfxVolume;
    public Toggle map, speed;
    public bool paused = false;

    private void Start()
    {
        musicVolume.value = PlayerPrefs.GetFloat("Music");
        sfxVolume.value = PlayerPrefs.GetFloat("Sfx");
        map.isOn = PlayerPrefs.GetInt("Map") == 1;
        speed.isOn = PlayerPrefs.GetInt("Gauge") == 1;
        ac.PlaySound("Car Engine");
        ac.PlaySound("Music");
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            paused = !paused;
        }
        pauseScreen.SetActive(paused);
        ac.SetVolume("Music", musicVolume.value);
        ac.SetVolume("Checkpoint", sfxVolume.value);
        ac.SetVolume("Car Engine", sfxVolume.value / 2f);
        ac.SetVolume("CVA", sfxVolume.value);
        miniMap.SetActive(map.isOn);
        speedGauge.SetActive(speed.isOn);

        if (paused)
        {
            ac.Pause("Car Engine");
            Cursor.visible = true;
            Time.timeScale = 0;
        }
        else
        {
            ac.Unpause("Car Engine");
            Cursor.visible = false;
            Time.timeScale = 1;
        }

        
    }
    public void SetPauseState(bool state)
    {
        paused = state;
    }
}
