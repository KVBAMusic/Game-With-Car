using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

public class ResetButton : MonoBehaviour
{
    public void ResetCar()
    {
        GameObject.FindGameObjectWithTag("Car").GetComponent<PlayerMovement>().ResetCar();
    }
}
