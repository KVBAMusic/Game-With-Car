﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.IO;

public class SceneLoader : MonoBehaviour
{
    public int scene;
    public Slider music, sfx, progressBar;
    public Toggle map, speed;
    public GameObject loadingText;
    public HighscoreManager hm;
    // Start is called before the first frame update
    public void OnClick()
    {
        if (loadingText != null) loadingText.SetActive(true);
        PlayerPrefs.SetFloat("Music", music.value);
        PlayerPrefs.SetFloat("Sfx", sfx.value);
        PlayerPrefs.SetInt("Map", map.isOn ? 1 : 0);
        PlayerPrefs.SetInt("Gauge", speed.isOn ? 1 : 0);
        hm.UpdateHighscores();
        StartCoroutine(LoadScene());
    }

    public void SetSceneNumber(int index)
    {
        scene = index;
    }

    IEnumerator LoadScene()
    {
        AsyncOperation loading = SceneManager.LoadSceneAsync(scene);
        while (!loading.isDone)
        {
            float progress = Mathf.Clamp01(loading.progress / .9f);
            if (progressBar != null) progressBar.value = progress;
            yield return null;
        }
    }

}