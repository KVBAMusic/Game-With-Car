﻿using UnityEngine;

public static class Constants
{
    public const int numberOfTracks = 10;
    public const string version = "0.1.3";
    public const string p_version = "0.1.2";
}
