using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneLoaded : MonoBehaviour
{
    public Transform initCarTransform;
    Vector3 initPos, initEuler;
    public AudioClip lap, check;

    private void Awake()
    {
        CarLoader cl = GetComponent<CarLoader>();
        GameObject car;
        if (PlayerPrefs.HasKey("Car Model")) car = cl.GetCarPrefab(PlayerPrefs.GetInt("Car Model"), false);
        else car = cl.GetCarPrefab(0, false);
        initPos = initCarTransform.position;
        initEuler = initCarTransform.eulerAngles;
        Instantiate(car, initPos, Quaternion.Euler(initEuler));
        car.GetComponent<TimerCheckpoints>().lap = lap;
        car.GetComponent<TimerCheckpoints>().check = check;
    }
}
