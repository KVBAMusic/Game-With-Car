﻿using UnityEngine;
using System.Collections;
public class FPSLimiter : MonoBehaviour
{
    public int targetFPS = 60;

    private void Awake()
    {
        DontDestroyOnLoad(this.gameObject);
        QualitySettings.vSyncCount = 0;
        Application.targetFrameRate = targetFPS;
    }
    void Update()
    {
        if(Application.targetFrameRate != targetFPS)
        {
            Application.targetFrameRate = targetFPS;
        }
    }
}