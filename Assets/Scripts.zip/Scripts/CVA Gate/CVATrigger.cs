using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CVATrigger : MonoBehaviour
{
    Rigidbody rb;
    Vector3 euler;
    bool active;
    Transform temp;
    AudioController ac;
    public ParticleSystem particles;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        ac = FindObjectOfType<AudioController>();
    }

    private void FixedUpdate()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            ResetCar();
        }

        if (active)
        {
            transform.rotation = Quaternion.Lerp(transform.rotation, temp.rotation, Time.fixedDeltaTime * 2.5f) ;
            rb.velocity = 50 * temp.forward;
            rb.angularVelocity = Vector3.zero;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        switch (other.gameObject.tag)
        {
            case "CVA Trigger":
                ac.PlaySound("CVA");
                particles.Play();
                euler = other.gameObject.GetComponent<CVADirection>().euler + new Vector3(0, 90, 0);
                temp = other.gameObject.transform;
                temp.eulerAngles = euler;
                transform.position += transform.up * 1;
                active = true;
                break;
            case "CVA Disable":
                active = false;
                particles.Stop();
                break;
            default:
                return;
        }
    }

    public void ResetCar()
    {
        active = false;
        rb.isKinematic = false;
        particles.Stop();
    }
}
