using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CVAGate : MonoBehaviour
{
    float i;
    public float speed;
    public Transform frame;

    // Update is called once per frame
    void Update()
    {
        frame.localEulerAngles = new Vector3(0, i, 0);
        i += Time.deltaTime * speed;
    }
}
