using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CVADirection : MonoBehaviour
{
    public Transform direction;
    public Vector3 euler;
    private void Start()
    {
        euler = direction.eulerAngles;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
