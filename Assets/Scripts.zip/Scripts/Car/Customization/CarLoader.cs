using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarLoader : MonoBehaviour
{
    public GameObject[] cars;

    public GameObject GetCarPrefab(int index, bool isInMenu)
    {
        GameObject car;
        try { 
            car = cars[index];
        }
        catch (System.IndexOutOfRangeException)
        {
            Debug.LogError("Car not defined. Loading default car");
            car = cars[0];
        }
        if (isInMenu)
        {
            car.GetComponent<PlayerMovement>().enabled = false;
            car.GetComponent<TimerCheckpoints>().enabled = false;
            car.GetComponent<SpeedIndicator>().enabled = false;
            car.GetComponent<CVATrigger>().enabled = false;
            car.GetComponent<Rigidbody>().isKinematic = true;
        }
        else
        {
            car.GetComponent<PlayerMovement>().enabled = true;
            car.GetComponent<TimerCheckpoints>().enabled = true;
            car.GetComponent<SpeedIndicator>().enabled = true;
            car.GetComponent<CVATrigger>().enabled = true;
            car.GetComponent<Rigidbody>().isKinematic = false;
        }
        return car;
    }
}
