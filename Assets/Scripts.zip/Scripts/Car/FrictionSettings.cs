﻿using System;
using UnityEngine;

public class FrictionSettings : MonoBehaviour
{
    public FrictionSetting[] settings;
}

