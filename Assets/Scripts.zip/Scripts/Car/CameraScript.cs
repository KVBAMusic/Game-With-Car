﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScript : MonoBehaviour
{
    Transform car;
    public Camera mainCamera, frontcamera;
    public int cameras;
    int activeCamera = 0;
    Transform frontCamTransform;

    private void Start()
    {
        car = GameObject.FindGameObjectWithTag("Car").transform;
        frontCamTransform = frontcamera.GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        frontCamTransform.position = car.position + (car.forward * 2.7f) + car.up * 1.5f;
        frontCamTransform.rotation = car.rotation;
        if (Input.GetKeyDown(KeyCode.C))
        {
            activeCamera++;
            if (activeCamera >= cameras)
            {
                activeCamera = 0;
            }
        }
        UpdateCamera();
    }

    private void UpdateCamera()
    {
        mainCamera.enabled = activeCamera == 0;
        frontcamera.enabled = activeCamera == 1;
    }
}
