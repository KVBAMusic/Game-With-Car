﻿using UnityEngine;
using System;

public class WheelPhysics : MonoBehaviour
{
    public WheelCollider wc;
    float fwdFriction, sideFriction;
    //public MeshCollider track;
   // public TerrainCollider terrain;
   // public Collider[] ice;
    public FrictionSettings fs;
    void Start()
    {
        wc = GetComponent<WheelCollider>();
        //foreach (Collider i in ice)
        //{
        //    i.tag = "Ice";
        //}
       // track.tag = "Track";
        //terrain.tag = "Terrain";
        fwdFriction = 2;
        sideFriction = 2;
    }

    private void FixedUpdate()
    {
        WheelHit wh = new WheelHit();
        wc.GetGroundHit(out wh);
        if (wh.collider == null) return;
        else
        {
            float ff = fwdFriction, sf = sideFriction;
            try
            {
                FrictionSetting setting = Array.Find(fs.settings, set => set.name == wh.collider.gameObject.tag);
                wc.forwardFriction = setting.GetFrictionCurve(0);
                wc.sidewaysFriction = setting.GetFrictionCurve(1);
            }
            catch (NullReferenceException)
            {
                return;
            }
        }
    }

    WheelFrictionCurve WCInit(float exSlip, float exValue, float asSlip, float asValue, float stiffness)
    {
        WheelFrictionCurve t = new WheelFrictionCurve();
        t.extremumSlip = exSlip;
        t.extremumValue = exValue;
        t.asymptoteSlip = asSlip;
        t.asymptoteValue = asValue;
        t.stiffness = stiffness;
        return t;
    }
}