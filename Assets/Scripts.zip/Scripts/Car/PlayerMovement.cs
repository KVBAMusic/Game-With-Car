﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public Renderer carBody;
    public Rigidbody rb;
    public WheelCollider rr, rl, fr, fl;
    public float torque, torqueOnMaxSpeed, minSteerAngle, maxSteerAngle, brakeTorque, idleBrakeTorque, downforce, maxSpeed, maxSpeedOnTerrain;
    public Transform trr, trl, tfr, tfl;
    public bool reversing = false;
    public Vector3 rightWheelsModifier, leftWheelsModifier;
    bool respawned = false;
    Vector3 respawnPosition;
    Quaternion respawnRotation;
    TimerCheckpoints tc;
    float temp_vel;

    private void Awake()
    {
        int c;
        if (PlayerPrefs.HasKey("Car Colour")) c = PlayerPrefs.GetInt("Car Colour");
        else c = 0;
        carBody.material.color = CustomizationEncoder.GetColour(c);
    }

    private void Start()
    {
        respawnPosition = transform.position;
        respawnRotation = transform.rotation;
        rb.centerOfMass = new Vector3(0f, -0.2f, 0f);
        tc = GetComponent<TimerCheckpoints>();
    }
    private void Update()
    {
        UpdateWheel(rr, trr, -1);
        UpdateWheel(rl, trl, 1);
        UpdateWheel(fr, tfr, -1);
        UpdateWheel(fl, tfl, 1);
        if (Input.GetKeyDown(KeyCode.R) && !FindObjectOfType<Pause>().paused)
        {
            ResetCar();
            respawned = true;
        }
    }

    void UpdateWheel(WheelCollider collider, Transform wheel, int side)
    {
        Vector3 pos;
        Quaternion quat;
        collider.GetWorldPose(out pos, out quat);
        wheel.position = pos;
        wheel.rotation = quat;
        switch (PlayerPrefs.HasKey("Car Model") ? PlayerPrefs.GetInt("Car Model") : 0)
        {
            case 0:
                break;
            case 1:
                Vector3 localPos = wheel.localPosition;
                localPos.z += .25f * (localPos.z / 1.8f);
                wheel.localPosition = localPos;
                break;
            case 2:
                break;
                
        }
    }

    public bool IsGrounded()
    {
        return (fr.isGrounded && fl.isGrounded && rr.isGrounded && rl.isGrounded);
    }

    public bool IsGroundedAny()
    {
        return (fr.isGrounded || fl.isGrounded || rr.isGrounded || rl.isGrounded);
    }

    private void FixedUpdate()
    {
        float inputVertical = Input.GetAxis("Vertical"), inputHorizontal = Input.GetAxis("Horizontal");
        temp_vel = rb.velocity.magnitude;
        Accelerate(inputVertical);
        
        if (temp_vel >= maxSpeed)
        {
            rb.velocity = rb.velocity.normalized * maxSpeed;
        }
        Steer();
        rb.AddForce(temp_vel * transform.up * downforce * -1f);
        Vector3 localVelocity = transform.InverseTransformDirection(rb.velocity);
        if (localVelocity.z * inputVertical < 0) Deccelerate(brakeTorque);

        if (localVelocity.z > -1f) reversing = false;
        else if (inputVertical == -1) reversing = true;

        if (inputVertical == 0) Deccelerate(idleBrakeTorque);
        else Deccelerate(0);
        FindObjectOfType<AudioController>().SetPitch("Car Engine", Mathf.Lerp(1, 3, temp_vel / maxSpeed));
        if (respawned)
        {
            Deccelerate(Mathf.Infinity);
            rb.isKinematic = true;
            respawned = false;
        }
        else
        {
            rb.isKinematic = false;
            Deccelerate(0);
        }
        
    }

    void Accelerate(float direction)
    {
        /*if (rb.velocity.magnitude <= .5f)
        {
            if (direction == -1)
            {
                reversing = true;
            }
            else
            {
                reversing = false;
            }
        }*/
        rr.motorTorque = Mathf.Lerp(torque, torqueOnMaxSpeed, temp_vel / maxSpeed) * direction;
        rl.motorTorque = Mathf.Lerp(torque, torqueOnMaxSpeed, temp_vel / maxSpeed) * direction;
        fr.motorTorque = Mathf.Lerp(torque, torqueOnMaxSpeed, temp_vel / maxSpeed) * direction;
        fl.motorTorque = Mathf.Lerp(torque, torqueOnMaxSpeed, temp_vel / maxSpeed) * direction;
    }
    void Deccelerate(float torque)
    {
        rr.brakeTorque = torque;
        rl.brakeTorque = torque;
        fr.brakeTorque = torque;
        fl.brakeTorque = torque;
    }

    void Steer()
    {
        float i = rb.velocity.magnitude / maxSpeed;
        fr.steerAngle = Mathf.Lerp(maxSteerAngle, minSteerAngle, i) * Input.GetAxis("Horizontal");
        fl.steerAngle = Mathf.Lerp(maxSteerAngle, minSteerAngle, i) * Input.GetAxis("Horizontal");
        rr.steerAngle = Mathf.Lerp(maxSteerAngle, minSteerAngle, i) * Input.GetAxis("Horizontal") * -1f;
        rl.steerAngle = Mathf.Lerp(maxSteerAngle, minSteerAngle, i) * Input.GetAxis("Horizontal") * -1f;
    }

    public void ResetCar()
    {
        transform.position = respawnPosition;
        transform.rotation = respawnRotation;
        rb.velocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
        Accelerate(0);
        tc.ResetTimer();
        fr.motorTorque = 0;
        fl.motorTorque = 0;
        rr.motorTorque = 0;
        rl.motorTorque = 0;
        rb.isKinematic = false;
    }

}
