﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

public class CameraTarget : MonoBehaviour
{
    Transform car;
    PlayerMovement pm;
    public float smooth;
    public CinemachineFreeLook cam;
    public GameObject carBody;
    Quaternion targetRotation;
    Rigidbody carRb;
    bool resetting = false;
    // Start is called before the first frame update
    void Start()
    {
        car = GameObject.FindGameObjectWithTag("Car").transform;
        carRb = car.gameObject.GetComponent<Rigidbody>();
        pm = GameObject.FindGameObjectWithTag("Car").GetComponent<PlayerMovement>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        transform.position = car.position + transform.up * .9f;
        if (car.position.y <= 0f)
        {
            transform.position = new Vector3(transform.position.x, 0, transform.position.z);
            cam.m_LookAt = car;
            if (!resetting)
            { 
                StartCoroutine(RespawnCar());
                resetting = true;
            }

        }
        if (pm.IsGroundedAny()) targetRotation = car.rotation;
        if (pm.reversing)
        {
            Vector3 a = car.eulerAngles;
            a.y -= 180f;
            a.x *= -1;
            targetRotation.eulerAngles = a;
        }
        transform.rotation = Quaternion.Lerp(transform.rotation, targetRotation, smooth * Time.fixedDeltaTime);
        //transform.rotation = targetRotation;
        if (Input.GetKeyDown(KeyCode.R)) ResetCar();
        
    }

    IEnumerator RespawnCar()
    {
        yield return new WaitForSeconds(2);
        car.gameObject.GetComponent<PlayerMovement>().ResetCar();
        resetting = false;
    }

    public void ResetCar()
    {
        cam.m_LookAt = transform;
    }
}
