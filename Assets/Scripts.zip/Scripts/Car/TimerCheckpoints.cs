﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class TimerCheckpoints : MonoBehaviour
{
    Text text, s1, s2, s3, bestTime;
    AudioController ac;
    public AudioClip lap, check;
    HighscoreManager hm;
    int checkpoint = 0;
    float startTick, cp1Tick, cp2Tick, endTick, t;

    void Start()
    {
        text = GameObject.Find("Time").GetComponent<Text>();
        s1 = GameObject.Find("S1").GetComponent<Text>();
        s2 = GameObject.Find("S2").GetComponent<Text>();
        s3 = GameObject.Find("S3").GetComponent<Text>();
        bestTime = GameObject.Find("Best time").GetComponent<Text>();
        ac = FindObjectOfType<AudioController>();
        hm = FindObjectOfType<HighscoreManager>();
        ResetTimer();
    }

    private void Update()
    {
        t = (Time.time - startTick);
        if (checkpoint > 0)
        {
            text.text = Format(t);
        }
        float hs = hm.GetHighscore(SceneManager.GetActiveScene().buildIndex - 1)[0];
        if (hs == -1)
        {
            bestTime.text = "Best time\n-:--.--";
        }
        else
        {
            bestTime.text = "Best time\n" + Format(hs);
        }
    }

    public void ResetTimer()
    {
        text.color = Color.white;
        text.text = "0:00.00";
        s1.text = "Sector 1 -:--.--";
        s2.text = "Sector 2 -:--.--";
        s3.text = "Sector 3 -:--.--";
        checkpoint = 0;
        startTick = 0;
        cp1Tick = 0;
        cp2Tick = 0;
        endTick = 0;
    }

    string Format(float time)
    {
        float ms = Mathf.Floor(time * 100);
        float seconds = Mathf.Floor(ms / 100);
        float minutes = Mathf.Floor(seconds / 60);
        string ms_s = (ms - seconds * 100).ToString();
        string seconds_s = (seconds - minutes * 60).ToString();
        string minutes_s = minutes.ToString();
        for (int i = ms_s.Length; i < 2; i++)
        {
            ms_s = "0" + ms_s;
        }
        for (int i = seconds_s.Length; i < 2; i++)
        {
            seconds_s = "0" + seconds_s;
        }
        return minutes_s + ":" + seconds_s + "." + ms_s;
    }

    private void OnTriggerEnter(Collider other)
    {
        switch(other.gameObject.tag)
        {
            case "Start":
                ac.SetClip("Checkpoint", lap);
                if (checkpoint == 0)
                {
                    startTick = Time.time;
                    checkpoint = 1;
                    text.color = Color.yellow;
                    ac.PlaySound("Checkpoint");
                }
                else if (checkpoint == 3)
                {
                    endTick = Time.time;
                    checkpoint = -1;
                    s3.text = "Sector 3 " + Format(endTick - cp2Tick);
                    text.color = Color.green;
                    ac.PlaySound("Checkpoint");
                    hm.CheckForHighscore(t, cp1Tick - startTick, cp2Tick - cp1Tick, endTick - cp2Tick);
                }
                break;
            case "CP1":
                ac.SetClip("Checkpoint", check);
                if (checkpoint == 1)
                {
                    cp1Tick = Time.time;
                    checkpoint = 2;
                    s1.text = "Sector 1 " + Format(cp1Tick - startTick);
                    ac.PlaySound("Checkpoint");
                }
                break;
            case "CP2":
                if (checkpoint == 2)
                {
                    cp2Tick = Time.time;
                    checkpoint = 3;
                    s2.text = "Sector 2 " + Format(cp2Tick - cp1Tick);
                    ac.PlaySound("Checkpoint");
                }
                break;
        }
    }
}
