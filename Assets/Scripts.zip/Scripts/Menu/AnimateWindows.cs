﻿using UnityEngine;
using System.Collections;

public class AnimateWindows : MonoBehaviour
{
    public RectTransform target, thisT;
    float smoothing = 10f;

    private void Awake()
    {
    }

    public void Animate()
    {
        target.position = new Vector3(Screen.width, 0, 0);
        thisT.position = new Vector3(Screen.width/ 2, Screen.height/2, 0);
        target.gameObject.SetActive(true);
        StartCoroutine(Animation());
    }

    IEnumerator Animation()
    {
        Vector3 thisDestination = new Vector3((Screen.width / -2), Screen.height / 2, 0);
        Vector3 targetDestination = new Vector3(Screen.width / 2, Screen.height / 2, 0);
        while (thisT.position.x > (Screen.width / -2) + 2)
        {
            target.position = Vector3.Lerp(target.position, targetDestination, smoothing * Time.deltaTime);
            thisT.position = Vector3.Lerp(thisT.position, thisDestination, smoothing * Time.deltaTime);
            yield return new WaitForEndOfFrame();
        }
        Debug.Log("Animation stopped");
        target.position = targetDestination;
        thisT.gameObject.SetActive(false);
    }
}