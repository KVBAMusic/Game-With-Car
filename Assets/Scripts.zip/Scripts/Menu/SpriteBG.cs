﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpriteBG : MonoBehaviour
{
    // Update is called once per frame
    void Update()
    {
        transform.localScale = new Vector3((float)Screen.width/170, (float)Screen.height/110, 1);
    }
}
