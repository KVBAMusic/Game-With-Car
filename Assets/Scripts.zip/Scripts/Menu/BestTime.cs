﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BestTime : MonoBehaviour
{
    public SceneLoader sl;
    public HighscoreManager hm;
    public Text[] texts;

    string Format(float time)
    {
        float ms = Mathf.Floor(time * 100);
        float seconds = Mathf.Floor(ms / 100);
        float minutes = Mathf.Floor(seconds / 60);
        string ms_s = (ms - seconds * 100).ToString();
        string seconds_s = (seconds - minutes * 60).ToString();
        string minutes_s = minutes.ToString();
        for (int i = ms_s.Length; i < 2; i++)
        {
            ms_s = "0" + ms_s;
        }
        for (int i = seconds_s.Length; i < 2; i++)
        {
            seconds_s = "0" + seconds_s;
        }
        return minutes_s + ":" + seconds_s + "." + ms_s;
    }

    public void ShowBestTime()
    {
        float[] highscore = hm.GetHighscore(sl.scene - 1);
        string output;
        for (int i = 0; i < 4; i++)
        {
            output = "";
            switch (highscore[i])
            {
                case -1:
                    output = "-:--.--";
                    break;
                default:
                    output = Format(hm.GetHighscore(sl.scene - 1)[i]);
                    break;
            }

            texts[i].text = output;
        }
        
    }

    private void OnEnable()
    {
        ShowBestTime();
    }
}
