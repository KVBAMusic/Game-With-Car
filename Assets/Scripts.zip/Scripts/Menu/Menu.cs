﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Menu : MonoBehaviour
{
    public Slider music, sfx;
    public Toggle map, speed;
    public AudioController ac;

    private void Start()
    {
        music.value = GetSliderValue("Music");
        sfx.value = GetSliderValue("Sfx");
        map.isOn = GetToggleValue("Map");
        speed.isOn = GetToggleValue("Gauge");
        ac.PlaySound("Music");
        Time.timeScale = 1;
    }

    float GetSliderValue(string key, float default_ = .5f)
    {
        return PlayerPrefs.HasKey(key) ? PlayerPrefs.GetFloat(key) : default_;
    }    

    bool GetToggleValue(string key, bool default_ = true)
    {
        return PlayerPrefs.HasKey(key) ? PlayerPrefs.GetInt(key) == 1 : default_;
    }

    private void Update()
    {
        ac.SetVolume("Music", music.value);
    }
}