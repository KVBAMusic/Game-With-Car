using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ImagePreview : MonoBehaviour
{
    public SpriteRenderer image, bg;
    public Sprite[] sprites;
    float a = 1, speed = 10;
    public void SetImage(int index)
    {
        bg.sprite = sprites[index];
        StartCoroutine(Fade(index));
    }

    IEnumerator Fade(int index)
    {
        while (a > 0)
        {
            a -= Time.deltaTime * speed;
            yield return null;
        }
        image.sprite = sprites[index];
        a = 1;
    }

    private void Update()
    {
        image.color = new Color(.46f, .46f, .46f, a);
        bg.transform.position = image.transform.position + new Vector3(0, 0, a);
    }
}
