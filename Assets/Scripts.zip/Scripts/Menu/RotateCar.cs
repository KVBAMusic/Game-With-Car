﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RotateCar : MonoBehaviour
{
    Transform car;
    GameObject carBody;

    private void Awake()
    {
        int index = PlayerPrefs.HasKey("Car Model") ? PlayerPrefs.GetInt("car Model") : 0;
        GameObject car_temp = gameObject.GetComponent<CarLoader>().GetCarPrefab(index, true);
        Instantiate(car_temp, transform);
        car = GameObject.FindGameObjectWithTag("Car").transform;
        carBody = GameObject.FindGameObjectWithTag("Car Body");
    }

    private void OnDisable()
    {
        StopCoroutine(Rotate());
    }

    private void OnEnable()
    {
        StartCoroutine(Rotate());
        if (!PlayerPrefs.HasKey("Car Colour")) carBody.GetComponent<Renderer>().material.color = Color.red;
        else
        {
            int i = PlayerPrefs.GetInt("Car Colour");
            carBody.GetComponent<Renderer>().material.color = CustomizationEncoder.GetColour(i);
        }
        if (!PlayerPrefs.HasKey("Car Model")) carBody.GetComponent<Renderer>().material.color = Color.red;
        else
        {
            int i = PlayerPrefs.GetInt("Car Model");
            ChangeCar(i);
        }
    }

    public IEnumerator Rotate()
    {
        while (true)
        {

            try {
                int w = Screen.width, h = Screen.height;
                car.position = new Vector3(5, -2, 10);
                car.Rotate(new Vector3(0, .3f, 0));
            }
            catch(MissingReferenceException)
            {
                car = GameObject.FindGameObjectWithTag("Car").transform;
                carBody = GameObject.FindGameObjectWithTag("Car Body");
            }
            catch (System.NullReferenceException)
            {
                car = GameObject.FindGameObjectWithTag("Car").transform;
                carBody = GameObject.FindGameObjectWithTag("Car Body");
            }
            yield return new WaitForSeconds(.01f);
        }
    }

    public void SetColour(int colour)
    {
        PlayerPrefs.SetInt("Car Colour", colour);
        carBody.GetComponent<Renderer>().material.color = CustomizationEncoder.GetColour(colour);
    }

    public void ChangeCar(int index)
    {
        GameObject car_temp = gameObject.GetComponent<CarLoader>().GetCarPrefab(index, true);
        Destroy(car.gameObject);
        Instantiate(car_temp, transform);
        car = GameObject.FindGameObjectWithTag("Car").transform;
        carBody = GameObject.FindGameObjectWithTag("Car Body");
        PlayerPrefs.SetInt("Car Model", index);
    }
}
