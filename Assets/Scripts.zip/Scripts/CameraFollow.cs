using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform car, target;
    public float smoohting;
    Vector3 euler;
    Camera cam;
    PlayerMovement pm;
    // Start is called before the first frame update
    void Start()
    {
        cam = GetComponent<Camera>();
        pm = GameObject.FindWithTag("Car").GetComponent<PlayerMovement>();
    }

    // Update is called once per frame
    void LateUpdate()
    {
        transform.rotation = Quaternion.Lerp(transform.rotation, target.rotation, smoohting * (int)(1 / Time.unscaledDeltaTime));
        euler = transform.eulerAngles;
        euler.z = 0;
        euler.x = 15 + car.eulerAngles.x * (pm.reversing ? -1 : 1);
        transform.eulerAngles = euler;
        transform.position = target.position + transform.TransformVector(new Vector3(0, .5f, -7));
    }
}
